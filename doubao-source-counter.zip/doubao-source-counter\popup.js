const $=s=>document.querySelector(s),message=p=>chrome.runtime.sendMessage(p);
const SITE_NAMES={"douyin.com":"抖音","sohu.com":"搜狐","volcengine.com":"火山引擎","100ec.cn":"网经社","china.com":"中华网","weixin.qq.com":"微信公众平台","qq.com":"腾讯网","baidu.com":"百度","zhihu.com":"知乎","toutiao.com":"今日头条","163.com":"网易","sina.com.cn":"新浪","thepaper.cn":"澎湃新闻","ithome.com":"IT之家","36kr.com":"36氪","cnblogs.com":"博客园","csdn.net":"CSDN","bilibili.com":"哔哩哔哩","xiaohongshu.com":"小红书","taogaofen.com":"淘高分"};
const siteLabel=s=>SITE_NAMES[s]?`${SITE_NAMES[s]} · ${s}`:s;
function esc(s){let d=document.createElement("div");d.textContent=s??"";return d.innerHTML}
function flash(b,t="完成"){let old=b.textContent;b.textContent=t;setTimeout(()=>b.textContent=old,1000)}
async function render(){
  let{data}=await message({type:"GET_STATS"}),ss=data.sessions||[],active=ss.find(s=>s.id===data.activeSessionId),last=active||ss.at(-1),counts=last?.counts||{},rows=Object.entries(counts).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])),records=last?data.records.filter(r=>r.sessionId===last.id):[],total=rows.reduce((n,[,v])=>n+v,0);
  $("#summary").textContent=active?"正在统计当前聊天窗口":last?`上次结束于 ${new Date(last.endedAt||last.startedAt).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}`:"尚未开始统计";
  $("#refCount").textContent=total;$("#siteCount").textContent=rows.length;$("#answerCount").textContent=records.length;
  $("#start").disabled=!!active;$("#stop").disabled=!active;$("#empty").hidden=!!last;$("#result").hidden=!last;
  $("tbody").innerHTML=rows.map(([s,n])=>`<tr><td title="${esc(s)}">${esc(siteLabel(s))}</td><td>${n}</td></tr>`).join("");
  let items=records.flatMap(r=>(r.items||r.urls?.map(u=>({title:u,url:u,site:(()=>{try{return new URL(u).hostname}catch{return""}})()}))||[])).slice(-5).reverse();
  $("#recent").innerHTML=items.length?items.map(x=>`<div class="recent-item" title="${esc(x.title)}"><div class="recent-title">${esc(x.title||x.url)}</div><div class="recent-meta">${esc(siteLabel(x.site||""))}</div></div>`).join(""):`<div class="empty-recent">暂无明细</div>`;
}
$("#start").onclick=async e=>{let[t]=await chrome.tabs.query({active:true,currentWindow:true});try{let r=await chrome.tabs.sendMessage(t.id,{type:"START_TRACKING"});if(!r?.ok)throw 0;flash(e.target,"统计中");setTimeout(render,1500)}catch{flash(e.target,"请刷新豆包页")}};
$("#stop").onclick=async e=>{let[t]=await chrome.tabs.query({active:true,currentWindow:true});try{await chrome.tabs.sendMessage(t.id,{type:"STOP_TRACKING"});await render();flash(e.target,"已保存")}catch{flash(e.target,"结束失败")}};
$("#csv").onclick=async e=>{await message({type:"EXPORT_CSV"});flash(e.target)};$("#json").onclick=async e=>{await message({type:"EXPORT_JSON"});flash(e.target)};
$("#clear").onclick=async e=>{if(confirm("确定清空全部统计记录吗？")){await message({type:"CLEAR_STATS"});await render();flash(e.target)}};render();
